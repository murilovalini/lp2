﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtPalavra.Text;

            texto = texto.Replace(" ", "");
            texto = texto.ToUpper();

            string invertido = "";

            for (int i = texto.Length - 1; i >= 0; i--)
            {
                invertido += texto[i];
            }

            if (texto == invertido)
            {
                MessageBox.Show("É um palíndromo.");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }
    }
}
