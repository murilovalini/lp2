﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void txtNome_Validated(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int producao;
            double salario, gratificacao, salarioBruto;

            if (!int.TryParse(txtProdu.Text, out producao) ||
                !double.TryParse(txtSalario.Text, out salario) ||
                !double.TryParse(txtGrati.Text, out gratificacao))
            {
                MessageBox.Show("Digite valores válidos.");
                return;
            }

            double bonus = 0;

            if (producao >= 100)
                bonus += 0.05;

            if (producao >= 120)
                bonus += 0.10;

            if (producao >= 150)
                bonus += 0.10;

            salarioBruto = salario + (salario * bonus) + gratificacao;

            if (salarioBruto > 7000 && producao < 150)
            {
                MessageBox.Show("Salário bruto não pode passar de 7000.");
            }
            else
            {
                MessageBox.Show(
                    "Nome: " + txtNome.Text +
                    "\nMatrícula: " + txtMatricula.Text +
                    "\nSalário Bruto: R$ " + salarioBruto.ToString("F2")
                );
            }
        }
    }
}
