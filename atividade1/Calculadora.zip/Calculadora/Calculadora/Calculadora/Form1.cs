﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        Double Num1, Num2, Resultado;

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            { return; }

            if (!Double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Número inválido!");
                txtNum2.Focus();
            }
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            Resultado = Num1 + Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
            Num1 = 0;
            Num2 = 0;
            Resultado = 0;
            txtNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
            
            Resultado = Num1 + Num2;
            
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Num1 - Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Num2 == 0)
            {
                MessageBox.Show("Divisão por zero não é permitida. Por favor, insira um número diferente de zero para o número 2.");
                txtNum2.Clear();
                txtNum2.Focus();
                return;
            }

            Resultado = Num1 / Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {

            Resultado = Num1 * Num2;
            txtResultado.Text = Resultado.ToString();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            { return; }

            if (!Double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Número inválido!");
                txtNum1.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
