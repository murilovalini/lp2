﻿namespace PtesteMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btnverificar = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(123, 45);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(233, 26);
            this.txtpalavra1.TabIndex = 0;
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(23, 45);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra1.TabIndex = 1;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(23, 124);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra2.TabIndex = 2;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(123, 124);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(233, 26);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btnverificar
            // 
            this.btnverificar.Location = new System.Drawing.Point(27, 241);
            this.btnverificar.Name = "btnverificar";
            this.btnverificar.Size = new System.Drawing.Size(176, 105);
            this.btnverificar.TabIndex = 4;
            this.btnverificar.Text = "Verificar iguais ";
            this.btnverificar.UseVisualStyleBackColor = true;
            // 
            // btninserir1
            // 
            this.btninserir1.Location = new System.Drawing.Point(309, 241);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(176, 105);
            this.btninserir1.TabIndex = 5;
            this.btninserir1.Text = "inserir 1º meio 2º";
            this.btninserir1.UseVisualStyleBackColor = true;
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(589, 241);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(176, 105);
            this.btninserir2.TabIndex = 6;
            this.btninserir2.Text = "inserir** meio 1º";
            this.btninserir2.UseVisualStyleBackColor = true;
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btnverificar);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btnverificar;
        private System.Windows.Forms.Button btninserir1;
        private System.Windows.Forms.Button btninserir2;
    }
}