﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtPalavra.Text.Length; i++)
            {
                if (rchtxtPalavra.Text[i] == ' ')
                {
                    posicao = i;
                }
            }
            MessageBox.Show("Espacos em branco: " + posicao);

        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int letraR = 0;

            for (int i = 0; i < rchtxtPalavra.Text.Length; i++)
            {
                if (rchtxtPalavra.Text[i] == 'r' || rchtxtPalavra.Text[i] == 'R')
                {
                    letraR++;
                }
            }
            MessageBox.Show("Letras R: " + letraR);
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int pares = 0;

            for (int i = 0; i < rchtxtPalavra.Text.Length - 1; i++)
            {
                if (rchtxtPalavra.Text[i] == rchtxtPalavra.Text[i + 1])
                {
                    pares++;
                }
            }
            MessageBox.Show("Tem letras juntas: " + pares);
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
