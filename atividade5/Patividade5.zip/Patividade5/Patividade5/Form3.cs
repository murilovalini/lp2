﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        int N = 0;
        double H = 0;
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            H = 0;

            for (int i = 1; i <= N; i++)
            {
                H += 1.0 / i;
            }

            MessageBox.Show("Valor de H = " + H.ToString("F2"));
        }

        private void txtNumeroN_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(txtNumeroN.Text, out N))
            {
                MessageBox.Show("Digite apenas números.");
                txtNumeroN.Clear();
                txtNumeroN.Focus();
                return;
            }
            else if (N <= 0)
            {
                MessageBox.Show("Digite um número maior que 0.");
                txtNumeroN.Clear();
                txtNumeroN.Focus();
            }
        }
    }
}
